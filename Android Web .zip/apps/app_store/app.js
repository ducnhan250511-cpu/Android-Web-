
export const template = `
<div class="store">
  <style>
    .store { display:flex; flex-direction:column; height:100%; min-height:0; overflow:hidden;
      font-family:var(--font-ui); color:var(--text-main); position:relative;
      background:radial-gradient(circle at 50% 0%,rgba(200,170,110,.1),transparent 55%),
                 linear-gradient(180deg,#0a1428,#010a13); }
    .store__head { flex:0 0 auto; padding:14px 16px 8px; border-bottom:1px solid rgba(200,170,110,.2); }
    .store__head h3 { margin:0; font-family:var(--font-display); color:var(--hex-gold);
      letter-spacing:3px; font-size:15px; }
    .store__head p { margin:4px 0 0; font-size:11px; color:var(--text-dim); }
    .store__grid { flex:1 1 auto; min-height:0; overflow:auto; padding:14px; display:grid;
      grid-template-columns:repeat(auto-fill,minmax(230px,1fr)); gap:12px; align-content:start; }
    .store__card { padding:12px; border-radius:10px; display:flex; gap:12px;
      background:linear-gradient(145deg,rgba(10,20,40,.92),rgba(0,90,130,.25));
      border:1px solid rgba(200,170,110,.3); transition:all .18s; }
    .store__card:hover { border-color:var(--hex-gold); box-shadow:var(--glow-gold); }
    .store__icon { width:52px; height:52px; flex:0 0 auto; display:grid; place-items:center;
      font-size:26px; border-radius:10px;
      background:linear-gradient(145deg,rgba(10,20,40,.9),rgba(0,90,130,.5));
      border:1px solid rgba(200,170,110,.3); }
    .store__info { flex:1; min-width:0; display:flex; flex-direction:column; }
    .store__name { font-size:13px; color:var(--hex-gold-light); font-family:var(--font-display); }
    .store__meta { font-size:10px; color:var(--text-dim); margin-top:2px; }
    .store__desc { font-size:11px; color:var(--text-main); margin:6px 0 8px;
      display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical;
      overflow:hidden; line-height:1.4; }
    .store__btn { align-self:flex-start; margin-top:auto; padding:5px 14px;
      font-size:11px; letter-spacing:1px; border-radius:6px; cursor:pointer;
      color:var(--hex-void); background:linear-gradient(145deg,var(--hex-gold),var(--hex-gold-dark));
      border:1px solid var(--hex-gold-light); transition:all .15s; }
    .store__btn:hover:not(:disabled) { box-shadow:var(--glow-gold); transform:translateY(-1px); }
    .store__btn:disabled { cursor:default; opacity:.6;
      background:rgba(31,191,117,.35); color:var(--hex-gold-light); }
    .store__toast { position:absolute; left:50%; bottom:24px;
      transform:translateX(-50%) translateY(20px);
      padding:8px 18px; font-size:12px; border-radius:20px;
      background:rgba(31,191,117,.95); color:#fff; box-shadow:0 6px 22px rgba(0,0,0,.6);
      opacity:0; transition:all .3s; pointer-events:none; z-index:10; }
    .store__toast.is-on { opacity:1; transform:translateX(-50%) translateY(0); }
  </style>
  <div class="store__head">
    <h3>⬢ HEXTECH APP STORE</h3>
    <p>Cài app → icon xuất hiện trên màn hình chính</p>
  </div>
  <div class="store__grid" data-role="grid"></div>
  <div class="store__toast" data-role="toast">✓ Đã cài đặt</div>
</div>
`;

const CATALOG = [
  { id:'calculator', name:'Hex Calculator', icon:'🧮', version:'1.0', size:'8 KB',
    desc:'Máy tính Hextech với 4 phép toán cơ bản và hỗ trợ bàn phím.',
    entry:'./apps/calculator/app.js' },
  { id:'notes', name:'Hex Notes', icon:'📝', version:'1.0', size:'6 KB',
    desc:'Ghi chú nhanh, tự động lưu vào localStorage.',
    entry:'./apps/notes/app.js' }
];

const STORAGE_KEY = 'lolos.installed';

export default class AppStore {
  constructor(root, ctx) {
    this.root = root; this.ctx = ctx;
    this.grid  = root.querySelector('[data-role="grid"]');
    this.toast = root.querySelector('[data-role="toast"]');
    if (!this.grid) { console.error('[Store] Thiếu grid'); return; }

    this.catalog   = CATALOG;
    this.installed = this._safeLoad();
    this._bind();
    this._render();
  }
  _bind() {
    this.grid.addEventListener('click', e => {
      const b = e.target.closest('[data-install]'); if (!b) return;
      this._install(b.dataset.install, b);
    });
  }
  _render() {
    this.grid.innerHTML = '';
    for (const app of this.catalog) {
      const already = this.ctx.launcher.hasApp(app.id);
      const isInstalled = already || this.installed.includes(app.id);
      const card = document.createElement('div');
      card.className = 'store__card';
      card.innerHTML = `
        <div class="store__icon">${app.icon}</div>
        <div class="store__info">
          <div class="store__name">${app.name}</div>
          <div class="store__meta">v${app.version} · ${app.size}</div>
          <div class="store__desc">${app.desc}</div>
          <button class="store__btn" data-install="${app.id}" ${isInstalled ? 'disabled' : ''}>
            ${isInstalled ? '✓ ĐÃ CÀI' : 'CÀI ĐẶT'}
          </button>
        </div>`;
      this.grid.appendChild(card);
    }
  }
  _install(id, btn) {
    const app = this.catalog.find(a => a.id === id);
    if (!app) return;
    if (this.ctx.launcher.hasApp(app.id)) {
      btn.disabled = true; btn.textContent = '✓ ĐÃ CÀI';
      this._toast('App đã có'); return;
    }
    const ok = this.ctx.launcher.registerApp({
      id: app.id, name: app.name, icon: app.icon, entry: app.entry
    });
    if (ok) {
      if (!this.installed.includes(app.id)) this.installed.push(app.id);
      this._safeSave();
      btn.disabled = true; btn.textContent = '✓ ĐÃ CÀI';
      this._toast(`✓ Đã cài ${app.name} · Xem màn hình chính`);
    } else {
      btn.disabled = true; btn.textContent = '✓ ĐÃ CÀI';
      this._toast('App đã tồn tại');
    }
  }
  _toast(msg) {
    if (!this.toast) return;
    this.toast.textContent = msg;
    this.toast.classList.add('is-on');
    clearTimeout(this._t);
    this._t = setTimeout(() => this.toast.classList.remove('is-on'), 2200);
  }
  _safeLoad() { try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]'); } catch { return []; } }
  _safeSave() { try { localStorage.setItem(STORAGE_KEY, JSON.stringify(this.installed)); } catch {} }
  destroy() { clearTimeout(this._t); }
}