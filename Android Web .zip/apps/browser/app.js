/**
 * Hex Browser v5 - Dual Engine & Self-Contained Proxy Engine
 */

/* Tự đăng ký Custom Element x-frame-bypass an toàn nếu chưa tồn tại */
if (typeof customElements !== 'undefined' && !customElements.get('x-frame-bypass')) {
  customElements.define('x-frame-bypass', class extends HTMLIFrameElement {
    static get observedAttributes() { return ['src']; }
    attributeChangedCallback(name, oldValue, newValue) {
      if (name === 'src' && newValue && /^https?:\/\//i.test(newValue)) {
        this.load(newValue);
      }
    }
    connectedCallback() {
      this.sandbox = 'allow-forms allow-modals allow-pointer-lock allow-popups allow-same-origin allow-scripts allow-top-navigation-by-user-activation';
    }
    async load(url) {
      if (!url || !/^https?:\/\//i.test(url)) return;
      const proxies = [
        u => `https://corsproxy.io/?${encodeURIComponent(u)}`,
        u => `https://api.allorigins.win/raw?url=${encodeURIComponent(u)}`
      ];
      for (const proxyFn of proxies) {
        try {
          const res = await fetch(proxyFn(url));
          if (res.ok) {
            let html = await res.text();
            html = `<base href="${url}">${html}`;
            this.srcdoc = html;
            return;
          }
        } catch (e) {}
      }
      this.removeAttribute('is');
      this.src = url;
    }
  }, { extends: 'iframe' });
}

export const template = `
<div class="brw">
  <style>
    .brw { display:flex; flex-direction:column; height:100%; min-height:0; overflow:hidden;
      color: var(--text-main); font-family: var(--font-ui); }
    .brw__bar { flex:0 0 auto; display:flex; gap:6px; padding:8px; align-items:center;
      background: rgba(1,10,19,.92); border-bottom:1px solid rgba(200,170,110,.25); }
    .brw__btn { width:30px; height:30px; flex:0 0 auto; display:grid; place-items:center;
      border-radius:6px; background:rgba(200,170,110,.08); color:var(--hex-gold);
      border:1px solid rgba(200,170,110,.25); font-size:13px; transition:all .15s; cursor:pointer; }
    .brw__btn:hover:not(:disabled){ background:rgba(200,170,110,.22); box-shadow:var(--glow-gold); }
    .brw__btn:disabled{ opacity:.35; cursor:not-allowed; }
    .brw__btn--mode { color:var(--hex-cyan); font-size:11px; width:auto; padding:0 8px; }
    .brw__url { flex:1 1 auto; min-width:0; height:30px; padding:0 10px;
      background:rgba(10,20,40,.95); border:1px solid rgba(200,170,110,.3);
      color:var(--hex-gold-light); border-radius:6px; font-family:'Consolas',monospace; font-size:12px; }
    .brw__url:focus{ outline:none; border-color:var(--hex-cyan); box-shadow:0 0 8px rgba(10,200,185,.45); }
    .brw__viewport { flex:1 1 auto; min-height:0; position:relative; background:#0a1428; overflow:hidden; }
    .brw__frame { position:absolute; inset:0; width:100%; height:100%; border:0; background:#fff; }
    .brw__frame[hidden] { display:none !important; }
    .brw__home { position:absolute; inset:0; overflow:auto; padding:20px;
      display:grid; grid-template-columns:repeat(auto-fill,minmax(140px,1fr)); gap:12px; align-content:start; z-index:1;
      background:radial-gradient(circle at 50% 0%,rgba(10,200,185,.08),transparent 60%),
                 linear-gradient(180deg,#0a1428,#010a13); }
    .brw__home[hidden] { display:none !important; }
    .brw__home h2 { grid-column:1/-1; margin:0 0 8px; font-family:var(--font-display); color:var(--hex-gold); letter-spacing:3px; font-size:14px; }
    .brw__tile { padding:14px 8px; border-radius:8px; cursor:pointer; text-align:center;
      color:var(--hex-gold-light); transition:all .18s ease;
      background:linear-gradient(145deg,rgba(10,20,40,.9),rgba(0,90,130,.35)); border:1px solid rgba(200,170,110,.3); }
    .brw__tile:hover{ transform:translateY(-3px); box-shadow:var(--glow-gold); border-color:var(--hex-gold); }
    .brw__tile .em { display:block; font-size:26px; margin-bottom:6px; }
    .brw__tile .nm { font-size:11px; letter-spacing:.5px; }
    .brw__status { flex:0 0 auto; padding:4px 10px; font-size:11px; color:var(--text-dim);
      background:rgba(1,10,19,.95); border-top:1px solid rgba(200,170,110,.2);
      letter-spacing:.5px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
    .brw__err { position:absolute; inset:0; z-index:5; display:none;
      flex-direction:column; align-items:center; justify-content:center; gap:14px; padding:24px; text-align:center;
      background:linear-gradient(180deg,rgba(10,20,40,.98),rgba(1,10,19,.98)); }
    .brw__err.is-on { display:flex; }
    .brw__err h3 { margin:0; color:var(--hex-danger); font-family:var(--font-display); letter-spacing:2px; font-size:15px; }
    .brw__err p { margin:0; color:var(--text-dim); font-size:12px; max-width:320px; line-height:1.5; }
    .brw__err a { padding:8px 18px; border-radius:6px; text-decoration:none;
      color:var(--hex-void); background:linear-gradient(145deg,var(--hex-gold),var(--hex-gold-dark));
      border:1px solid var(--hex-gold-light); font-size:12px; letter-spacing:1px; transition:all .15s; }
    .brw__err a:hover { box-shadow:var(--glow-gold); transform:translateY(-1px); }
  </style>
  <div class="brw__bar">
    <button class="brw__btn" data-act="back"   title="Quay lại">◀</button>
    <button class="brw__btn" data-act="fwd"    title="Tiếp">▶</button>
    <button class="brw__btn" data-act="reload" title="Tải lại">🔄</button>
    <button class="brw__btn" data-act="home"   title="Trang chủ">🏠</button>
    <input class="brw__url" type="text" placeholder="Tìm Google hoặc nhập URL (vd: youtube.com, github.com)" />
    <button class="brw__btn" data-act="go" title="Đi">➔</button>
    <button class="brw__btn brw__btn--mode" data-act="mode" title="Chế độ trang">AUTO</button>
  </div>
  <div class="brw__viewport">
    <div class="brw__home" data-role="home"></div>
    <iframe class="brw__frame" data-role="frame-direct" hidden
            referrerpolicy="strict-origin-when-cross-origin"
            sandbox="allow-forms allow-modals allow-pointer-lock allow-popups allow-same-origin allow-scripts"></iframe>
    <iframe is="x-frame-bypass" class="brw__frame" data-role="frame-bypass" hidden></iframe>
    <div class="brw__err" data-role="err">
      <h3>KHÔNG THỂ TẢI TRANG TRỰC TIẾP</h3>
      <p data-role="err-msg">Trang web này từ chối nhúng iframe. Bạn có thể mở trong tab mới.</p>
      <a data-role="err-link" href="#" target="_blank" rel="noopener">🌐 MỞ TRONG TAB MỚI</a>
    </div>
  </div>
  <div class="brw__status" data-role="status">Hex Browser Engine Sẵn Sàng</div>
</div>
`;

export default class BrowserApp {
  constructor(root, ctx) {
    this.root = root; this.ctx = ctx;
    this.homeEl     = root.querySelector('[data-role="home"]');
    this.frameDirect= root.querySelector('[data-role="frame-direct"]');
    this.frameBypass= root.querySelector('[data-role="frame-bypass"]');
    this.urlInput   = root.querySelector('.brw__url');
    this.statusEl   = root.querySelector('[data-role="status"]');
    this.barEl      = root.querySelector('.brw__bar');
    this.errEl      = root.querySelector('[data-role="err"]');
    this.errMsg     = root.querySelector('[data-role="err-msg"]');
    this.errLink    = root.querySelector('[data-role="err-link"]');
    this.modeBtn    = root.querySelector('[data-act="mode"]');

    if (!this.homeEl || !this.frameDirect || !this.barEl) return;

    this.mode = 'auto';
    this.history = [];
    this.index   = -1;

    this.bookmarks = [
      { icon:'🔍', name:'Google Search', action:'search' },
      { icon:'▶️', name:'YouTube',        url:'https://www.youtube.com' },
      { icon:'💻', name:'GitHub',         url:'https://github.com' },
      { icon:'📖', name:'Wikipedia',      url:'https://en.m.wikipedia.org/wiki/League_of_Legends' },
      { icon:'🌐', name:'Example Site',   url:'https://example.com' },
      { icon:'🗺️', name:'OpenStreetMap',  url:'https://www.openstreetmap.org/export/embed.html?bbox=105.7,20.9,106.1,21.2&layer=mapnik' }
    ];

    this._renderHome();
    this._bind();
    this._go('home');
  }

  _resolveUrl(input) {
    const v = input.trim();
    if (!v) return null;

    const ytMatch = v.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]+)/);
    if (ytMatch) {
      return `https://www.youtube.com/embed/${ytMatch[1]}?autoplay=1`;
    }

    if (/^https?:\/\//i.test(v)) return v;
    if (/^[\w-]+(\.[\w-]+)+(\/.*)?$/i.test(v)) return 'https://' + v;
    return 'https://www.google.com/search?q=' + encodeURIComponent(v) + '&igu=1';
  }

  _pickFrameMode(url) {
    if (this.mode === 'direct') return 'direct';
    if (this.mode === 'bypass') return 'bypass';
    if (/google\.[a-z.]+\/search/i.test(url) && url.includes('igu=1')) return 'direct';
    if (/wikipedia\.org|openstreetmap\.org|example\.com|youtube\.com\/embed/i.test(url)) return 'direct';
    return 'bypass';
  }

  _submit() {
    const url = this._resolveUrl(this.urlInput.value);
    if (url) this._go(url);
  }

  _go(url) {
    if (url !== 'home' && url === this.history[this.index]) {
      this._reload();
      return;
    }
    this.history = this.history.slice(0, this.index + 1);
    this.history.push(url);
    this.index = this.history.length - 1;
    this._render();
  }

  _back()    { if (this.index > 0) { this.index--; this._render(); } }
  _forward() { if (this.index < this.history.length - 1) { this.index++; this._render(); } }

  _reload() {
    const url = this.history[this.index];
    if (!url || url === 'home') return;
    this._blankFrame(this.frameDirect);
    this._blankFrame(this.frameBypass);
    this._render();
  }

  _render() {
    const url = this.history[this.index];
    this._hideError();

    if (url === 'home') {
      this._showHome();
      return;
    }

    this.homeEl.hidden = true;
    const which = this._pickFrameMode(url);
    const frame = which === 'bypass' ? this.frameBypass : this.frameDirect;
    const other = which === 'bypass' ? this.frameDirect : this.frameBypass;

    other.hidden = true;
    this._blankFrame(other);

    frame.hidden = false;
    this._setSrc(frame, url);

    this.urlInput.value = this._displayUrl(url);
    this._setStatus(`🌐 [${which.toUpperCase()}] Đang tải: ${this._displayUrl(url)}`);
    this._syncButtons();
  }

  _showHome() {
    this.homeEl.hidden = false;
    this.frameDirect.hidden = true;
    this.frameBypass.hidden = true;
    this._blankFrame(this.frameDirect);
    this._blankFrame(this.frameBypass);
    this.urlInput.value = '';
    this._setStatus('Trang chủ Hex Browser - Chọn Bookmark hoặc tìm kiếm');
    this._syncButtons();
  }

  _setSrc(frame, url) {
    if (!url || !/^https?:\/\//i.test(url)) {
      this._blankFrame(frame);
      return;
    }
    try {
      if (frame.hasAttribute('is')) {
        frame.setAttribute('src', url);
      } else {
        frame.src = url;
      }
    } catch (err) {}
  }

  _blankFrame(frame) {
    if (!frame) return;
    try {
      frame.removeAttribute('src');
      frame.removeAttribute('srcdoc');
    } catch {}
  }

  _displayUrl(url) {
    try {
      const u = new URL(url);
      if (u.hostname.includes('google') && u.searchParams.get('q')) {
        return '🔍 Google: ' + u.searchParams.get('q');
      }
      return u.hostname + (u.pathname !== '/' ? u.pathname : '');
    } catch {
      return url;
    }
  }

  _syncButtons() {
    const b = this.root.querySelector('[data-act="back"]');
    const f = this.root.querySelector('[data-act="fwd"]');
    if (b) b.disabled = this.index <= 0;
    if (f) f.disabled = this.index >= this.history.length - 1;
  }

  _setStatus(t) {
    if (this.statusEl) this.statusEl.textContent = t;
  }

  _showError(msg, url) {
    if (!this.errEl) return;
    if (this.errMsg) this.errMsg.textContent = msg;
    if (this.errLink && url) this.errLink.href = url;
    this.errEl.classList.add('is-on');
  }

  _hideError() {
    if (this.errEl) this.errEl.classList.remove('is-on');
  }

  _updateModeBtn() {
    if (!this.modeBtn) return;
    this.modeBtn.textContent = this.mode.toUpperCase();
  }

  _bind() {
    this.barEl.addEventListener('click', e => {
      const b = e.target.closest('[data-act]'); if (!b) return;
      const a = b.dataset.act;
      if (a === 'back')   this._back();
      if (a === 'fwd')    this._forward();
      if (a === 'reload') this._reload();
      if (a === 'home')   this._go('home');
      if (a === 'go')     this._submit();
      if (a === 'mode')   this._cycleMode();
    });

    this.urlInput.addEventListener('keydown', e => {
      if (e.key === 'Enter') { this._submit(); e.preventDefault(); }
    });

    const onLoad = (which) => () => {
      const url = this.history[this.index];
      if (!url || url === 'home') return;
      if (this._pickFrameMode(url) !== which) return;
      this._setStatus(`✅ [${which.toUpperCase()}] Đã tải xong`);
      this._hideError();
    };

    this.frameDirect.addEventListener('load', onLoad('direct'));
    this.frameBypass.addEventListener('load', onLoad('bypass'));
  }

  _cycleMode() {
    const order = ['auto', 'direct', 'bypass'];
    const cur = order.indexOf(this.mode);
    this.mode = order[(cur + 1) % order.length];
    this._updateModeBtn();
    this._setStatus('Chế độ: ' + this.mode.toUpperCase());
    this._reload();
  }

  _renderHome() {
    this.homeEl.innerHTML = '<h2>✨ HEXTECH BROWSER</h2>';
    for (const b of this.bookmarks) {
      const el = document.createElement('div');
      el.className = 'brw__tile';
      el.innerHTML = `<span class="em">${b.icon}</span><span class="nm">${b.name}</span>`;
      el.addEventListener('click', () => {
        if (b.action === 'search') {
          this._go('home');
          this.urlInput.focus();
        } else {
          this._go(b.url);
        }
      });
      this.homeEl.appendChild(el);
    }
  }

  destroy() {
    this._blankFrame(this.frameDirect);
    this._blankFrame(this.frameBypass);
  }
}