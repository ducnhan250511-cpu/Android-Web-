export const template = `
<div class="calc">
  <style>
    .calc { display:flex; flex-direction:column; height:100%; min-height:0; padding:12px; gap:10px;
      font-family:var(--font-ui); color:var(--text-main);
      background:linear-gradient(180deg,#0a1428,#010a13); }
    .calc__screen { padding:14px; text-align:right; border-radius:10px;
      background:rgba(1,10,19,.9); border:1px solid rgba(200,170,110,.3);
      box-shadow:inset 0 0 18px rgba(10,200,185,.2); }
    .calc__expr { font-size:12px; color:var(--text-dim); min-height:16px;
      font-family:monospace; letter-spacing:1px; }
    .calc__val { font-size:30px; color:var(--hex-gold-light); font-family:var(--font-display);
      letter-spacing:1px; overflow:hidden; text-overflow:ellipsis; }
    .calc__pad { flex:1 1 auto; min-height:0; display:grid; grid-template-columns:repeat(4,1fr);
      grid-auto-rows:1fr; gap:8px; }
    .calc__key { display:grid; place-items:center; font-size:18px; cursor:pointer;
      border-radius:8px; color:var(--hex-gold-light);
      background:rgba(10,20,40,.85); border:1px solid rgba(200,170,110,.25);
      transition:all .12s; user-select:none; font-family:var(--font-display); }
    .calc__key:hover { background:rgba(200,170,110,.18); box-shadow:var(--glow-gold); }
    .calc__key:active { transform:scale(.94); }
    .calc__key--op { color:var(--hex-cyan); }
    .calc__key--eq { background:linear-gradient(145deg,var(--hex-gold),var(--hex-gold-dark));
      color:var(--hex-void); border-color:var(--hex-gold-light); grid-column:span 2; }
    .calc__key--clr { color:var(--hex-danger); }
  </style>
  <div class="calc__screen">
    <div class="calc__expr" data-role="expr"></div>
    <div class="calc__val"  data-role="val">0</div>
  </div>
  <div class="calc__pad" data-role="pad">
    <div class="calc__key calc__key--clr" data-k="C">C</div>
    <div class="calc__key" data-k="(">(</div>
    <div class="calc__key" data-k=")">)</div>
    <div class="calc__key calc__key--op" data-k="/">÷</div>
    <div class="calc__key" data-k="7">7</div>
    <div class="calc__key" data-k="8">8</div>
    <div class="calc__key" data-k="9">9</div>
    <div class="calc__key calc__key--op" data-k="*">×</div>
    <div class="calc__key" data-k="4">4</div>
    <div class="calc__key" data-k="5">5</div>
    <div class="calc__key" data-k="6">6</div>
    <div class="calc__key calc__key--op" data-k="-">−</div>
    <div class="calc__key" data-k="1">1</div>
    <div class="calc__key" data-k="2">2</div>
    <div class="calc__key" data-k="3">3</div>
    <div class="calc__key calc__key--op" data-k="+">+</div>
    <div class="calc__key" data-k="0">0</div>
    <div class="calc__key" data-k=".">.</div>
    <div class="calc__key calc__key--eq" data-k="=">=</div>
  </div>
</div>
`;

export default class CalculatorApp {
  constructor(root, ctx) {
    this.root = root;
    this.expr = root.querySelector('[data-role="expr"]');
    this.val  = root.querySelector('[data-role="val"]');
    this.pad  = root.querySelector('[data-role="pad"]');
    if (!this.pad) { console.error('[Calc] Thiếu pad'); return; }
    this.buf = '';
    this.pad.addEventListener('click', e => {
      const k = e.target.closest('[data-k]'); if (!k) return;
      this._press(k.dataset.k);
    });
    this._onKey = (e) => {
      if (/^[0-9+\-*/().=]$/.test(e.key)) { this._press(e.key); e.preventDefault(); }
      if (e.key === 'Escape' || e.key.toLowerCase() === 'c') this._press('C');
      if (e.key === 'Backspace') this._back();
    };
    window.addEventListener('keydown', this._onKey);
  }
  _press(k) {
    if (k === 'C') { this.buf = ''; this._update('0'); return; }
    if (k === '=') {
      try {
        const r = Function('"use strict";return (' + this.buf + ')')();
        if (this.expr) this.expr.textContent = this.buf + ' =';
        this.buf = String(r);
        this._update(this.buf);
      } catch { this._update('⚠ Lỗi'); }
      return;
    }
    this.buf += k; this._update(this.buf);
  }
  _back() { this.buf = this.buf.slice(0, -1); this._update(this.buf || '0'); }
  _update(d) {
    if (this.val)  this.val.textContent  = d;
    if (this.expr) this.expr.textContent = this.buf;
  }
  destroy() { window.removeEventListener('keydown', this._onKey); }
}