export const template = `
<div class="notes">
  <style>
    .notes { display:flex; height:100%; min-height:0; overflow:hidden;
      font-family:var(--font-ui); color:var(--text-main);
      background:linear-gradient(180deg,#0a1428,#010a13); }
    .notes__side { width:130px; flex:0 0 auto; border-right:1px solid rgba(200,170,110,.2);
      display:flex; flex-direction:column; background:rgba(1,10,19,.75); }
    .notes__new { padding:10px; font-size:11px; letter-spacing:1px; cursor:pointer;
      background:linear-gradient(145deg,var(--hex-gold),var(--hex-gold-dark));
      color:var(--hex-void); border:0; border-bottom:1px solid rgba(200,170,110,.3);
      font-family:var(--font-display); }
    .notes__list { flex:1 1 auto; min-height:0; overflow:auto; }
    .notes__item { padding:8px 10px; font-size:11px; cursor:pointer;
      border-bottom:1px solid rgba(200,170,110,.08); color:var(--text-dim);
      white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
    .notes__item:hover { background:rgba(200,170,110,.08); }
    .notes__item.is-active { background:rgba(10,200,185,.15); color:var(--hex-gold-light);
      border-left:3px solid var(--hex-cyan); padding-left:7px; }
    .notes__main { flex:1; display:flex; flex-direction:column; min-width:0; }
    .notes__title { padding:8px 12px; background:rgba(1,10,19,.75);
      border:0; border-bottom:1px solid rgba(200,170,110,.15);
      color:var(--hex-gold-light); font-family:var(--font-display); font-size:14px; outline:none; }
    .notes__body { flex:1 1 auto; min-height:0; padding:12px; border:0; resize:none; outline:none;
      background:rgba(1,10,19,.55); color:var(--hex-gold-light);
      font-family:var(--font-ui); font-size:13px; line-height:1.6; }
    .notes__bar { padding:6px 12px; font-size:10px; color:var(--text-dim);
      background:rgba(1,10,19,.9); border-top:1px solid rgba(200,170,110,.15);
      display:flex; justify-content:space-between; }
    .notes__del { background:none; border:0; color:var(--hex-danger); cursor:pointer;
      font-size:10px; letter-spacing:1px; }
  </style>
  <aside class="notes__side">
    <button class="notes__new" data-role="new">+ GHI CHÚ MỚI</button>
    <div class="notes__list" data-role="list"></div>
  </aside>
  <section class="notes__main">
    <input class="notes__title" data-role="title" placeholder="Tiêu đề…" />
    <textarea class="notes__body" data-role="body" placeholder="Nội dung…"></textarea>
    <div class="notes__bar">
      <span data-role="status">Sẵn sàng</span>
      <button class="notes__del" data-role="del">🗑 XÓA</button>
    </div>
  </section>
</div>
`;

const KEY = 'lolos.notes';

export default class NotesApp {
  constructor(root, ctx) {
    this.root = root;
    this.title  = root.querySelector('[data-role="title"]');
    this.body   = root.querySelector('[data-role="body"]');
    this.list   = root.querySelector('[data-role="list"]');
    this.status = root.querySelector('[data-role="status"]');
    if (!this.title || !this.body) { console.error('[Notes] Thiếu element'); return; }

    this.notes = this._load();
    this.currentId = this.notes[0]?.id || null;

    const newBtn = root.querySelector('[data-role="new"]');
    const delBtn = root.querySelector('[data-role="del"]');
    if (newBtn) newBtn.addEventListener('click', () => this._new());
    if (delBtn) delBtn.addEventListener('click', () => this._del());

    const save = () => { this._persist(); this._render(); };
    this.title.addEventListener('input', save);
    this.body.addEventListener('input', save);

    if (this.list) this.list.addEventListener('click', e => {
      const it = e.target.closest('[data-id]'); if (!it) return;
      this._select(it.dataset.id);
    });

    this._render();
    this._select(this.currentId);
  }
  _new() {
    const n = { id: Date.now().toString(), title:'', body:'' };
    this.notes.unshift(n); this.currentId = n.id;
    this._persist(); this._render(); this._select(n.id);
    this.title.focus();
  }
  _del() {
    if (!this.currentId) return;
    this.notes = this.notes.filter(n => n.id !== this.currentId);
    this.currentId = this.notes[0]?.id || null;
    this._persist(); this._render(); this._select(this.currentId);
  }
  _select(id) {
    this.currentId = id;
    const n = this.notes.find(x => x.id === id);
    this.title.value = n?.title || '';
    this.body.value  = n?.body  || '';
    this._render();
    if (this.status) this.status.textContent = n ? '✓ Đã lưu tự động' : 'Trống · bấm "+"';
  }
  _persist() {
    const n = this.notes.find(x => x.id === this.currentId);
    if (n) { n.title = this.title.value; n.body = this.body.value; }
    try { localStorage.setItem(KEY, JSON.stringify(this.notes)); } catch {}
  }
  _load() { try { return JSON.parse(localStorage.getItem(KEY) || '[]'); } catch { return []; } }
  _render() {
    if (!this.list) return;
    this.list.innerHTML = '';
    for (const n of this.notes) {
      const el = document.createElement('div');
      el.className = 'notes__item';
      el.dataset.id = n.id;
      if (n.id === this.currentId) el.classList.add('is-active');
      el.textContent = n.title?.trim() || '(không tiêu đề)';
      this.list.appendChild(el);
    }
  }
  destroy() { this._persist(); }
}export const template = `
<div class="notes">
  <style>
    .notes { display:flex; height:100%; min-height:0; overflow:hidden;
      font-family:var(--font-ui); color:var(--text-main);
      background:linear-gradient(180deg,#0a1428,#010a13); }
    .notes__side { width:130px; flex:0 0 auto; border-right:1px solid rgba(200,170,110,.2);
      display:flex; flex-direction:column; background:rgba(1,10,19,.75); }
    .notes__new { padding:10px; font-size:11px; letter-spacing:1px; cursor:pointer;
      background:linear-gradient(145deg,var(--hex-gold),var(--hex-gold-dark));
      color:var(--hex-void); border:0; border-bottom:1px solid rgba(200,170,110,.3);
      font-family:var(--font-display); }
    .notes__list { flex:1 1 auto; min-height:0; overflow:auto; }
    .notes__item { padding:8px 10px; font-size:11px; cursor:pointer;
      border-bottom:1px solid rgba(200,170,110,.08); color:var(--text-dim);
      white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
    .notes__item:hover { background:rgba(200,170,110,.08); }
    .notes__item.is-active { background:rgba(10,200,185,.15); color:var(--hex-gold-light);
      border-left:3px solid var(--hex-cyan); padding-left:7px; }
    .notes__main { flex:1; display:flex; flex-direction:column; min-width:0; }
    .notes__title { padding:8px 12px; background:rgba(1,10,19,.75);
      border:0; border-bottom:1px solid rgba(200,170,110,.15);
      color:var(--hex-gold-light); font-family:var(--font-display); font-size:14px; outline:none; }
    .notes__body { flex:1 1 auto; min-height:0; padding:12px; border:0; resize:none; outline:none;
      background:rgba(1,10,19,.55); color:var(--hex-gold-light);
      font-family:var(--font-ui); font-size:13px; line-height:1.6; }
    .notes__bar { padding:6px 12px; font-size:10px; color:var(--text-dim);
      background:rgba(1,10,19,.9); border-top:1px solid rgba(200,170,110,.15);
      display:flex; justify-content:space-between; }
    .notes__del { background:none; border:0; color:var(--hex-danger); cursor:pointer;
      font-size:10px; letter-spacing:1px; }
  </style>
  <aside class="notes__side">
    <button class="notes__new" data-role="new">+ GHI CHÚ MỚI</button>
    <div class="notes__list" data-role="list"></div>
  </aside>
  <section class="notes__main">
    <input class="notes__title" data-role="title" placeholder="Tiêu đề…" />
    <textarea class="notes__body" data-role="body" placeholder="Nội dung…"></textarea>
    <div class="notes__bar">
      <span data-role="status">Sẵn sàng</span>
      <button class="notes__del" data-role="del">🗑 XÓA</button>
    </div>
  </section>
</div>
`;

const KEY = 'lolos.notes';

export default class NotesApp {
  constructor(root, ctx) {
    this.root = root;
    this.title  = root.querySelector('[data-role="title"]');
    this.body   = root.querySelector('[data-role="body"]');
    this.list   = root.querySelector('[data-role="list"]');
    this.status = root.querySelector('[data-role="status"]');
    if (!this.title || !this.body) { console.error('[Notes] Thiếu element'); return; }

    this.notes = this._load();
    this.currentId = this.notes[0]?.id || null;

    const newBtn = root.querySelector('[data-role="new"]');
    const delBtn = root.querySelector('[data-role="del"]');
    if (newBtn) newBtn.addEventListener('click', () => this._new());
    if (delBtn) delBtn.addEventListener('click', () => this._del());

    const save = () => { this._persist(); this._render(); };
    this.title.addEventListener('input', save);
    this.body.addEventListener('input', save);

    if (this.list) this.list.addEventListener('click', e => {
      const it = e.target.closest('[data-id]'); if (!it) return;
      this._select(it.dataset.id);
    });

    this._render();
    this._select(this.currentId);
  }
  _new() {
    const n = { id: Date.now().toString(), title:'', body:'' };
    this.notes.unshift(n); this.currentId = n.id;
    this._persist(); this._render(); this._select(n.id);
    this.title.focus();
  }
  _del() {
    if (!this.currentId) return;
    this.notes = this.notes.filter(n => n.id !== this.currentId);
    this.currentId = this.notes[0]?.id || null;
    this._persist(); this._render(); this._select(this.currentId);
  }
  _select(id) {
    this.currentId = id;
    const n = this.notes.find(x => x.id === id);
    this.title.value = n?.title || '';
    this.body.value  = n?.body  || '';
    this._render();
    if (this.status) this.status.textContent = n ? '✓ Đã lưu tự động' : 'Trống · bấm "+"';
  }
  _persist() {
    const n = this.notes.find(x => x.id === this.currentId);
    if (n) { n.title = this.title.value; n.body = this.body.value; }
    try { localStorage.setItem(KEY, JSON.stringify(this.notes)); } catch {}
  }
  _load() { try { return JSON.parse(localStorage.getItem(KEY) || '[]'); } catch { return []; } }
  _render() {
    if (!this.list) return;
    this.list.innerHTML = '';
    for (const n of this.notes) {
      const el = document.createElement('div');
      el.className = 'notes__item';
      el.dataset.id = n.id;
      if (n.id === this.currentId) el.classList.add('is-active');
      el.textContent = n.title?.trim() || '(không tiêu đề)';
      this.list.appendChild(el);
    }
  }
  destroy() { this._persist(); }
}