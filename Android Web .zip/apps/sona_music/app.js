/**
 * Sona Music v4 - Inline Template & Safe Audio Engine
 */
export const template = `
<div class="sona">
  <style>
    .sona { display:flex; flex-direction:column; height:100%; min-height:0; overflow:hidden;
      font-family:var(--font-ui); color:var(--text-main);
      background:radial-gradient(circle at 50% 0%,rgba(10,200,185,.12),transparent 55%),
                 linear-gradient(180deg,#0a1428,#010a13); }
    .sona__head { flex:0 0 auto; display:flex; gap:14px; align-items:center; padding:12px 16px 8px; }
    .sona__disc { width:62px; height:62px; flex:0 0 auto; border-radius:50%; display:grid; place-items:center;
      font-size:26px; background:conic-gradient(from 0deg,#0a1428,#005a82,#0a1428,#005a82,#0a1428);
      border:2px solid var(--hex-gold); box-shadow:var(--glow-gold),inset 0 0 14px rgba(10,200,185,.4);
      transition:transform .3s; }
    .sona__disc.is-spinning { animation:sona-spin 6s linear infinite; }
    @keyframes sona-spin { to { transform:rotate(360deg); } }
    .sona__meta { min-width:0; flex:1; }
    .sona__title { font-family:var(--font-display); font-size:14px; color:var(--hex-gold-light);
      white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
    .sona__artist { font-size:11px; color:var(--text-dim);
      white-space:nowrap; overflow:hidden; text-overflow:ellipsis; margin-top:2px; }
    .sona__viz { flex:0 0 42px; width:100%; display:block; background:rgba(1,10,19,.4);
      border-top:1px solid rgba(200,170,110,.12); border-bottom:1px solid rgba(200,170,110,.12); }
    .sona__seek { flex:0 0 auto; display:flex; align-items:center; gap:8px;
      padding:6px 14px 0; font-size:10px; color:var(--text-dim); font-family:monospace; }
    .sona input[type=range] { -webkit-appearance:none; appearance:none; flex:1; height:3px;
      border-radius:99px; background:rgba(200,170,110,.25); outline:none; cursor:pointer; }
    .sona input[type=range]::-webkit-slider-thumb { -webkit-appearance:none; width:11px; height:11px;
      border-radius:50%; background:var(--hex-gold); box-shadow:var(--glow-gold); }
    .sona input[type=range]::-moz-range-thumb { width:11px; height:11px; border:none;
      border-radius:50%; background:var(--hex-gold); cursor:pointer; }
    .sona__ctrl { flex:0 0 auto; display:flex; align-items:center; justify-content:center;
      gap:8px; padding:8px 14px 12px; flex-wrap:wrap; }
    .sona__btn { width:34px; height:34px; border-radius:50%; display:grid; place-items:center;
      font-size:13px; color:var(--hex-gold); background:rgba(10,20,40,.85);
      border:1px solid rgba(200,170,110,.4); transition:all .15s; cursor:pointer; }
    .sona__btn:hover { color:var(--hex-gold-light); border-color:var(--hex-gold); box-shadow:var(--glow-gold); }
    .sona__btn.is-active { background:rgba(0,90,130,.6); border-color:var(--hex-cyan);
      color:var(--hex-gold-light); box-shadow:var(--glow-cyan); }
    .sona__btn--main { width:46px; height:46px; font-size:18px;
      background:linear-gradient(145deg,var(--hex-gold),var(--hex-gold-dark));
      color:var(--hex-void); border-color:var(--hex-gold-light); }
    .sona__vol { display:flex; align-items:center; gap:5px; width:80px; font-size:11px; color:var(--text-dim); }
    .sona__list { flex:1 1 auto; min-height:0; overflow-y:auto; margin:0 8px 8px;
      border-radius:8px; background:rgba(1,10,19,.6); border:1px solid rgba(200,170,110,.2); }
    .sona__list h4 { margin:0; padding:7px 12px; font-size:10px; letter-spacing:2px;
      color:var(--hex-gold); border-bottom:1px solid rgba(200,170,110,.15);
      position:sticky; top:0; background:rgba(10,20,40,.95); z-index:1; }
    .sona__item { display:flex; align-items:center; gap:9px; padding:7px 12px;
      cursor:pointer; font-size:12px; transition:background .12s;
      border-bottom:1px solid rgba(200,170,110,.06); }
    .sona__item:hover { background:rgba(200,170,110,.08); }
    .sona__item.is-playing { background:rgba(10,200,185,.12); color:var(--hex-gold-light);
      border-left:3px solid var(--hex-cyan); padding-left:9px; }
    .sona__item .idx { font-family:monospace; font-size:10px; color:var(--text-dim); width:18px; flex:0 0 auto; }
    .sona__item .meta { flex:1; min-width:0; }
    .sona__item .meta b { display:block; font-weight:500; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
    .sona__item .meta i { font-style:normal; font-size:10px; color:var(--text-dim); }
  </style>
  <div class="sona__head">
    <div class="sona__disc" data-role="disc">🎵</div>
    <div class="sona__meta">
      <div class="sona__title"  data-role="title">Sona Music</div>
      <div class="sona__artist" data-role="artist">Chọn bài nhạc để nghe</div>
    </div>
  </div>
  <canvas class="sona__viz" data-role="viz"></canvas>
  <div class="sona__seek">
    <span data-role="cur">0:00</span>
    <input type="range" data-role="seek" min="0" max="100" value="0" step="0.1" />
    <span data-role="dur">0:00</span>
  </div>
  <div class="sona__ctrl">
    <button class="sona__btn" data-act="prev" title="Bài trước">⏮</button>
    <button class="sona__btn sona__btn--main" data-act="play" title="Phát / Tạm dừng">▶</button>
    <button class="sona__btn" data-act="next" title="Bài sau">⏭</button>
    <button class="sona__btn" data-act="shuffle" title="Ngẫu nhiên">🔀</button>
    <button class="sona__btn" data-act="repeat"  title="Lặp lại">🔁</button>
    <div class="sona__vol">🔊 <input type="range" data-role="vol" min="0" max="1" step="0.01" value="0.7" /></div>
  </div>
  <div class="sona__list">
    <h4>🎼 HEXTECH PLAYLIST - STREAMS & AUDIO</h4>
    <div data-role="playlist"></div>
  </div>
</div>
`;

const TRACKS = [
  { title: 'SomaFM - Indie Pop',    artist: 'Indie Rock Live',      url: 'https://ice2.somafm.com/indiepop-128-mp3' },
  { title: 'SomaFM - Groove Salad',  artist: 'Ambient Chill Live',   url: 'https://ice2.somafm.com/groovesalad-128-mp3' },
  { title: 'SomaFM - Drone Zone',    artist: 'Ambient Space Live',   url: 'https://ice2.somafm.com/dronezone-128-mp3' },
  { title: 'SomaFM - Lush',          artist: 'Vocal Chillout Live',  url: 'https://ice2.somafm.com/lush-128-mp3' },
  { title: 'SomaFM - DefCon Radio',  artist: 'Hacker Beats Live',    url: 'https://ice2.somafm.com/defcon-128-mp3' },
  { title: 'Lo-Fi Chill Song',       artist: 'Internet Archive',     url: 'https://ia801503.us.archive.org/15/items/chill-lofi-song/Chill%20Lofi%20Song.mp3' }
];

export default class SonaMusicApp {
  constructor(root, ctx) {
    this.root = root; this.ctx = ctx;
    this.disc     = root.querySelector('[data-role="disc"]');
    this.titleEl  = root.querySelector('[data-role="title"]');
    this.artistEl = root.querySelector('[data-role="artist"]');
    this.seek     = root.querySelector('[data-role="seek"]');
    this.cur      = root.querySelector('[data-role="cur"]');
    this.dur      = root.querySelector('[data-role="dur"]');
    this.vol      = root.querySelector('[data-role="vol"]');
    this.canvas   = root.querySelector('[data-role="viz"]');
    this.playBtn  = root.querySelector('[data-act="play"]');
    this.shuffleBtn = root.querySelector('[data-act="shuffle"]');
    this.repeatBtn  = root.querySelector('[data-act="repeat"]');
    this.listEl   = root.querySelector('[data-role="playlist"]');
    this.ctrlEl   = root.querySelector('.sona__ctrl');

    if (!this.ctrlEl || !this.listEl) return;

    /* KHÔNG ĐẶT crossOrigin để tránh lỗi chặn CORS đối với audio stream */
    this.audio = new Audio();
    this.audio.volume = 0.7;

    this.tracks  = TRACKS;
    this.current = 0;
    this.shuffle = false;
    this.repeat  = false;
    this.vizRAF  = null;

    this._bind();
    this._bindAudioEvents();
    this._renderPlaylist();
    this._showTrack(0);

    requestAnimationFrame(() => {
      this._setupCanvas();
      this._startViz();
    });
  }

  _renderPlaylist() {
    this.listEl.innerHTML = '';
    this.tracks.forEach((t, i) => {
      const el = document.createElement('div');
      el.className = 'sona__item';
      el.dataset.idx = i;
      el.innerHTML = `
        <span class="idx">${String(i+1).padStart(2,'0')}</span>
        <span class="meta"><b>${t.title}</b><i>${t.artist}</i></span>
        <span style="font-size:11px;color:var(--text-dim)">▶</span>`;
      el.addEventListener('click', () => this._play(i));
      this.listEl.appendChild(el);
    });
    this._highlight();
  }

  _highlight() {
    this.listEl.querySelectorAll('.sona__item').forEach((el, i) => {
      el.classList.toggle('is-playing', i === this.current);
    });
  }

  _play(i) {
    if (!this.tracks[i]) return;
    this.current = i;
    const t = this.tracks[i];
    this._showTrack(i);

    this.audio.src = t.url;
    this.audio.load();

    const playPromise = this.audio.play();
    if (playPromise !== undefined) {
      playPromise
        .then(() => { if (this.artistEl) this.artistEl.textContent = '🎶 ' + t.artist; })
        .catch(err => {
          console.warn('[Sona] Autoplay blocked:', err);
          if (this.titleEl) this.titleEl.textContent = t.title + ' (Nhấn Play để nghe)';
        });
    }
    this._highlight();
  }

  _showTrack(i) {
    const t = this.tracks[i]; if (!t) return;
    if (this.titleEl)  this.titleEl.textContent  = t.title;
    if (this.artistEl) this.artistEl.textContent = t.artist;
    if (this.disc)     this.disc.textContent     = '🎵';
  }

  _toggle() {
    if (!this.audio.src || this.audio.src === window.location.href) {
      this._play(this.current);
      return;
    }
    if (this.audio.paused) {
      this.audio.play().catch(e => console.warn('[Sona] Play error:', e));
    } else {
      this.audio.pause();
    }
  }

  _next() {
    const n = this.shuffle
      ? Math.floor(Math.random() * this.tracks.length)
      : (this.current + 1) % this.tracks.length;
    this._play(n);
  }

  _prev() {
    const p = (this.current - 1 + this.tracks.length) % this.tracks.length;
    this._play(p);
  }

  _bindAudioEvents() {
    this.audio.addEventListener('loadedmetadata', () => {
      if (this.dur) {
        this.dur.textContent = isFinite(this.audio.duration) ? this._fmt(this.audio.duration) : 'LIVE';
      }
    });

    this.audio.addEventListener('timeupdate', () => {
      if (this.cur) this.cur.textContent = this._fmt(this.audio.currentTime);
      if (this.seek) {
        if (isFinite(this.audio.duration) && this.audio.duration > 0) {
          this.seek.value = (this.audio.currentTime / this.audio.duration) * 100;
        } else {
          this.seek.value = 100;
        }
      }
    });

    this.audio.addEventListener('play', () => {
      if (this.playBtn) this.playBtn.textContent = '⏸';
      if (this.disc) this.disc.classList.add('is-spinning');
    });

    this.audio.addEventListener('pause', () => {
      if (this.playBtn) this.playBtn.textContent = '▶';
      if (this.disc) this.disc.classList.remove('is-spinning');
    });

    this.audio.addEventListener('ended', () => {
      if (this.repeat) { this.audio.currentTime = 0; this.audio.play(); }
      else this._next();
    });

    this.audio.addEventListener('error', () => {
      console.warn('[Sona] Audio Error:', this.audio.error);
      if (this.titleEl) this.titleEl.textContent = '⚠️ Không nạp được luồng nhạc';
    });
  }

  _bind() {
    this.ctrlEl.addEventListener('click', e => {
      const b = e.target.closest('[data-act]'); if (!b) return;
      const a = b.dataset.act;
      if (a === 'play')    this._toggle();
      if (a === 'next')    this._next();
      if (a === 'prev')    this._prev();
      if (a === 'shuffle') { this.shuffle = !this.shuffle; if (this.shuffleBtn) this.shuffleBtn.classList.toggle('is-active', this.shuffle); }
      if (a === 'repeat')  { this.repeat  = !this.repeat;  if (this.repeatBtn)  this.repeatBtn.classList.toggle('is-active', this.repeat); }
    });

    if (this.seek) {
      this.seek.addEventListener('input', () => {
        if (isFinite(this.audio.duration) && this.audio.duration > 0) {
          this.audio.currentTime = (this.seek.value / 100) * this.audio.duration;
        }
      });
    }

    if (this.vol) {
      this.vol.addEventListener('input', () => {
        this.audio.volume = parseFloat(this.vol.value);
      });
    }
  }

  _setupCanvas() {
    if (!this.canvas) return;
    const r = this.canvas.getBoundingClientRect();
    this.W = r.width || 300; this.H = r.height || 42;
    const dpr = window.devicePixelRatio || 1;
    this.canvas.width = this.W * dpr; this.canvas.height = this.H * dpr;
    this.ctx2d = this.canvas.getContext('2d');
    if (this.ctx2d) this.ctx2d.scale(dpr, dpr);
    this.bars = 40;
    this.heights = new Array(this.bars).fill(0);
  }

  _startViz() {
    const draw = () => {
      this.vizRAF = requestAnimationFrame(draw);
      if (!this.ctx2d) return;
      const playing = !this.audio.paused && !this.audio.ended;
      const t = performance.now() / 250;
      this.ctx2d.clearRect(0, 0, this.W, this.H);
      const g = this.ctx2d.createLinearGradient(0, this.H, 0, 0);
      g.addColorStop(0, '#c8aa6e'); g.addColorStop(1, '#0ac8b9');
      const bw = this.W / this.bars;
      for (let i = 0; i < this.bars; i++) {
        const target = playing
          ? (0.25 + 0.75 * Math.abs(Math.sin(t + i*0.4)*0.6 + Math.sin(t*1.7 + i*0.13)*0.4)) * (0.5 + 0.5*Math.random())
          : 0.03;
        this.heights[i] += (target - this.heights[i]) * 0.25;
        this.ctx2d.fillStyle = g;
        this.ctx2d.fillRect(i*bw + 1, this.H - this.heights[i]*this.H, bw - 2, this.heights[i]*this.H);
      }
    };
    draw();
  }

  _fmt(s) {
    if (!isFinite(s) || isNaN(s)) return '0:00';
    const m = Math.floor(s/60), sec = Math.floor(s%60);
    return `${m}:${String(sec).padStart(2,'0')}`;
  }

  destroy() {
    if (this.vizRAF) cancelAnimationFrame(this.vizRAF);
    this.audio.pause(); this.audio.src = ''; this.audio.load();
  }
}
