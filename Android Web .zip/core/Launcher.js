/**
 * Launcher v1.4 - Smart Template Resolver & App Manager
 */
const FALLBACK_APPS = [
  { id:'browser',    name:'Hex Browser', icon:'🌐', entry:'./apps/browser/app.js' },
  { id:'sona_music', name:'Sona Music',  icon:'🎵', entry:'./apps/sona_music/app.js' },
  { id:'app_store',  name:'Hex Store',   icon:'🛒', entry:'./apps/app_store/app.js' }
];

export class Launcher {
  #desktop; #wm; #apps = []; #manifestUrl;

  constructor({ desktop, windowManager, manifestUrl = './manifest.json' }) {
    if (!desktop)       throw new Error('[Launcher] Thiếu #desktop');
    if (!windowManager) throw new Error('[Launcher] Thiếu WindowManager');
    this.#desktop = desktop;
    this.#wm = windowManager;
    this.#manifestUrl = manifestUrl;
  }

  async init() {
    this.#apps = await this.#loadManifest();
    this.#renderHome();
    console.info(`[Launcher] Đã nạp ${this.#apps.length} ứng dụng.`);
  }

  getApps() { return [...this.#apps]; }
  hasApp(id) { return this.#apps.some(a => a.id === id); }

  registerApp(appDef) {
    if (!appDef?.id || this.hasApp(appDef.id)) return false;
    this.#apps.push(appDef);
    const grid = this.#desktop.querySelector('#home-grid');
    if (grid) grid.appendChild(this.#createIcon(appDef));
    console.info(`[Launcher] Mới: ${appDef.name}`);
    return true;
  }

  async launch(appId) {
    const app = this.#apps.find(a => a.id === appId);
    if (!app) return console.warn('[Launcher] Không có app:', appId);
    if (this.#wm.has(appId)) { this.#wm.focus(appId); return; }

    /* 1. Import module JS của App */
    let AppClass = null, inlineTemplate = '';
    try {
      const url = new URL(app.entry, document.baseURI).href;
      const mod = await import(/* @vite-ignore */ url);
      AppClass       = mod.default;
      inlineTemplate = mod.template || '';
    } catch (err) {
      console.error(`[Launcher] Import ${app.id} thất bại:`, err);
    }

    /* 2. Chọn UI Template (Ưu tiên inline template tự chứa trong file app.js) */
    let html = inlineTemplate;
    if (!html && app.ui) {
      try {
        const res = await fetch(app.ui, { cache: 'no-cache' });
        if (res.ok) {
          const text = await res.text();
          const isNotIndex = !text.includes('<title>LoL OS');
          if (text.length < 50000 && isNotIndex) {
            html = text;
          }
        }
      } catch (err) {
        console.warn(`[Launcher] Fetch ui.html thất bại:`, err.message);
      }
    }

    if (!html) {
      html = `<div style="padding:20px;color:#c8332b">App ${app.name} chưa có giao diện.</div>`;
    }

    /* 3. Mở cửa sổ hệ thống */
    const handle = this.#wm.open({
      appId: app.id, title: app.name, icon: app.icon, html
    });
    if (!handle) return;

    /* 4. Khởi chạy class điều khiển */
    if (typeof AppClass !== 'function') {
      console.error(`[Launcher] ${app.id}/app.js không export default class`);
      return;
    }

    try {
      const instance = new AppClass(handle.body, {
        wm: this.#wm, appId: app.id, app, launcher: this
      });
      handle.onDestroy = () => { try { instance.destroy?.(); } catch(e){} };
      console.info(`[Launcher] Đã chạy app: ${app.id}`);
    } catch (ctorErr) {
      console.error(`[Launcher] Lỗi khởi tạo ${app.id}:`, ctorErr);
      handle.body.innerHTML = `
        <div style="padding:24px;color:#c8332b;font-family:monospace;font-size:12px">
          Khởi chạy hỏng <b>${app.name}</b><br/><br/>
          ${ctorErr.message}
        </div>`;
    }
  }

  async #loadManifest() {
    try {
      const res = await fetch(this.#manifestUrl, { cache: 'no-cache' });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const text = await res.text();
      if (text.length > 20000) throw new Error('Manifest quá lớn');
      const data = JSON.parse(text);
      return Array.isArray(data.apps) ? data.apps.filter(a => a.installed !== false) : [];
    } catch (err) {
      console.warn('[Launcher] Dùng fallback manifest:', err.message);
      return FALLBACK_APPS;
    }
  }

  #renderHome() {
    const grid = document.createElement('div');
    grid.className = 'app-grid';
    grid.id = 'home-grid';
    for (const app of this.#apps) grid.appendChild(this.#createIcon(app));
    this.#desktop.appendChild(grid);
  }

  #createIcon(app) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'app-icon';
    btn.dataset.appId = app.id;
    btn.innerHTML = `
      <span class="app-icon__glyph">${app.icon}</span>
      <span class="app-icon__label">${app.name}</span>
    `;
    btn.addEventListener('click', () => this.launch(app.id));
    return btn;
  }
}
