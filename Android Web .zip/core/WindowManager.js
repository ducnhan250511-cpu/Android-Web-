/**
 * WindowManager v1.3 — Bulletproof
 * Mọi bước tạo window đều có try/catch + log rõ ràng.
 */
export class WindowManager {
  #desktop; #taskbarApps; #zTop = 100; #activeId = null; #cascade = 0;
  #windows = new Map();

  constructor({ desktop, taskbarApps = null }) {
    if (!desktop) throw new Error('[WM] Thiếu #desktop');
    this.#desktop = desktop;
    this.#taskbarApps = taskbarApps;
  }

  has(appId) { return this.#windows.has(appId); }

  open({ appId, title = 'App', icon = '⬢', html = '', onMount }) {
    // --- 1. Đã tồn tại → focus ---
    if (this.#windows.has(appId)) {
      const rec = this.#windows.get(appId);
      this.restore(appId); this.focus(appId);
      return rec.handle;
    }

    // --- 2. Tạo DOM an toàn ---
    const el = document.createElement('section');
    el.className = 'window is-opening';
    el.dataset.appId = appId;
    el.innerHTML = `
      <header class="window__bar" data-role="drag">
        <div class="window__title">
          <span class="window__icon">${icon}</span>
          <span class="window__name">${title}</span>
        </div>
        <div class="window__ctrl">
          <button class="win-btn" data-act="min"   title="Thu nhỏ">–</button>
          <button class="win-btn" data-act="max"   title="Mở rộng">▢</button>
          <button class="win-btn win-btn--close" data-act="close" title="Đóng">✕</button>
        </div>
      </header>
      <div class="window__body"></div>
      <div class="window__resizer" data-role="resize"></div>
    `;

    // --- 3. Inject app UI vào body (DÙNG <template> ĐỂ PARSE AN TOÀN) ---
    const bodyEl = el.querySelector('.window__body');
    if (!bodyEl) { console.error('[WM] Không có .window__body'); return null; }

    try {
      const tpl = document.createElement('template');
      tpl.innerHTML = String(html).trim();
      bodyEl.appendChild(tpl.content);   // <-- parse an toàn, không ảnh hưởng sibling
    } catch (err) {
      console.error('[WM] Lỗi inject HTML app:', err);
      bodyEl.textContent = '⚠ Không nạp được UI';
    }

    // --- 4. Đặt vị trí ---
    const dw = this.#desktop.clientWidth;
    const dh = this.#desktop.clientHeight;
    const w  = Math.min(560, dw - 24);
    const h  = Math.min(680, dh - 24);
    const step = this.#cascade % 5; this.#cascade++;
    const x = Math.max(12, (dw - w) / 2 + step * 18 - 36);
    const y = Math.max(12, (dh - h) / 2 + step * 14 - 30);
    Object.assign(el.style, { width: `${w}px`, height: `${h}px`, left: `${x}px`, top: `${y}px` });

    this.#desktop.appendChild(el);
    requestAnimationFrame(() => el.classList.remove('is-opening'));

    // --- 5. Gắn sự kiện (mọi element ĐỀU có null-check) ---
    const record = {
      id: appId, el, body: bodyEl, title, icon,
      minimized: false, maximized: false, handle: null
    };
    record.handle = {
      id: appId, el, body: bodyEl,
      focus:    () => this.focus(appId),
      close:    () => this.close(appId),
      minimize: () => this.minimize(appId),
      maximize: () => this.toggleMaximize(appId),
      setTitle: (t) => {
        record.title = t;
        const nameEl = el.querySelector('.window__name');
        if (nameEl) nameEl.textContent = t;
        this.#renderTaskbar();
      },
      onDestroy: null
    };
    this.#windows.set(appId, record);

    const safeClick = (sel, fn) => {
      const b = el.querySelector(sel);
      if (!b) { console.warn(`[WM] Không có nút ${sel}`); return; }
      b.addEventListener('click', e => { e.stopPropagation(); fn(); });
    };
    el.addEventListener('pointerdown', () => this.focus(appId), true);
    safeClick('[data-act="min"]',   () => this.minimize(appId));
    safeClick('[data-act="max"]',   () => this.toggleMaximize(appId));
    safeClick('[data-act="close"]', () => this.close(appId));

    const dragHandle = el.querySelector('[data-role="drag"]');
    const resizeGrip = el.querySelector('[data-role="resize"]');
    if (dragHandle) this.#makeDraggable(el, dragHandle);
    else console.warn('[WM] Không có [data-role="drag"]');
    if (resizeGrip) this.#makeResizable(el, resizeGrip);
    else console.warn('[WM] Không có [data-role="resize"]');

    this.focus(appId);
    this.#renderTaskbar();
    onMount?.(bodyEl, record.handle);
    console.info(`[WM] ✓ Mở window: ${appId}`);
    return record.handle;
  }

  focus(appId) {
    const rec = this.#windows.get(appId); if (!rec) return;
    rec.el.style.zIndex = ++this.#zTop;
    if (rec.minimized) this.restore(appId);
    this.#activeId = appId;
    this.#renderTaskbar();
  }
  minimize(appId) {
    const rec = this.#windows.get(appId); if (!rec) return;
    rec.minimized = true; rec.el.classList.add('is-minimized');
    if (this.#activeId === appId) this.#activeId = null;
    this.#renderTaskbar();
  }
  restore(appId) {
    const rec = this.#windows.get(appId); if (!rec) return;
    rec.minimized = false; rec.el.classList.remove('is-minimized');
    this.#renderTaskbar();
  }
  toggleMaximize(appId) {
    const rec = this.#windows.get(appId); if (!rec) return;
    rec.maximized = !rec.maximized;
    rec.el.classList.toggle('is-maximized', rec.maximized);
  }
  close(appId) {
    const rec = this.#windows.get(appId); if (!rec) return;
    try { rec.handle.onDestroy?.(); } catch (e) { console.warn('[WM] onDestroy lỗi:', e); }
    rec.el.remove();
    this.#windows.delete(appId);
    if (this.#activeId === appId) this.#activeId = null;
    this.#renderTaskbar();
  }

  #makeDraggable(el, handle) {
    let sx = 0, sy = 0, ox = 0, oy = 0, on = false;
    handle.addEventListener('pointerdown', (e) => {
      if (e.target.closest('.win-btn')) return;
      const rec = this.#windows.get(el.dataset.appId);
      if (rec?.maximized) return;
      on = true; sx = e.clientX; sy = e.clientY;
      ox = parseFloat(el.style.left) || 0;
      oy = parseFloat(el.style.top) || 0;
      handle.setPointerCapture(e.pointerId);
      el.classList.add('is-dragging');
      this.focus(el.dataset.appId);
    });
    handle.addEventListener('pointermove', (e) => {
      if (!on) return;
      const nx = ox + (e.clientX - sx);
      const ny = oy + (e.clientY - sy);
      const mx = this.#desktop.clientWidth - 60;
      const my = this.#desktop.clientHeight - 40;
      el.style.left = `${Math.min(Math.max(nx, -el.offsetWidth + 60), mx)}px`;
      el.style.top  = `${Math.min(Math.max(ny, 0), my)}px`;
    });
    const up = () => { on = false; el.classList.remove('is-dragging'); };
    handle.addEventListener('pointerup', up);
    handle.addEventListener('pointercancel', up);
  }

  #makeResizable(el, grip) {
    let sx = 0, sy = 0, w0 = 0, h0 = 0, on = false;
    grip.addEventListener('pointerdown', (e) => {
      e.stopPropagation();
      if (this.#windows.get(el.dataset.appId)?.maximized) return;
      on = true; sx = e.clientX; sy = e.clientY;
      w0 = el.offsetWidth; h0 = el.offsetHeight;
      grip.setPointerCapture(e.pointerId);
    });
    grip.addEventListener('pointermove', (e) => {
      if (!on) return;
      el.style.width  = `${Math.max(240, w0 + (e.clientX - sx))}px`;
      el.style.height = `${Math.max(180, h0 + (e.clientY - sy))}px`;
    });
    const up = () => { on = false; };
    grip.addEventListener('pointerup', up);
    grip.addEventListener('pointercancel', up);
  }

  #renderTaskbar() {
    if (!this.#taskbarApps) return;
    this.#taskbarApps.innerHTML = '';
    this.#windows.forEach((rec, id) => {
      const chip = document.createElement('button');
      chip.type = 'button';
      chip.className = 'task-chip';
      if (rec.minimized) chip.classList.add('is-minimized');
      if (this.#activeId === id) chip.classList.add('is-active');
      chip.innerHTML = `<span class="task-chip__icon">${rec.icon}</span><span>${rec.title}</span>`;
      chip.addEventListener('click', () => {
        if (rec.minimized || this.#activeId !== id) { this.restore(id); this.focus(id); }
        else this.minimize(id);
      });
      this.#taskbarApps.appendChild(chip);
    });
  }
}